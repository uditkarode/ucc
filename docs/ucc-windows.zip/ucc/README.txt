First open the UCC-INIT.bat file
once it completes, never run it again
add all your code in the sources folder, for example sources/test.cpp
to compile, use UCC-BUILD.bat
to run, use UCC-RUN.BAT
or you could just use UCC-BUILD-RUN.bat which does both

AFTER COMPILATION, 'xyz.cpp' BECOMES 'xyz.cpp.EXE'

if you prefer command line options, change directory to the assets folder
you can now use the above commands this way:
ucc -b test.cpp
ucc -r test.cpp.EXE
ucc -br test.cpp
