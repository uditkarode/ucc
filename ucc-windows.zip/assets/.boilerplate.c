#include <stdio.h>
#include <conio.h>

void main(){
	
	clrscr();
	
	getch();
}
