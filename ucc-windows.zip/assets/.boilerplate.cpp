#include <fstream.h>
#include <conio.h>

void main(){
	clrscr();
	
	getch();
}
